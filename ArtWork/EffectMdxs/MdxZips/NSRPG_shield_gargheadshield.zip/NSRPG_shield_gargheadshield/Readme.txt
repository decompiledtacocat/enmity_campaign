////////////////////////////////////////////////////////////
// N00byStance's RPG Gargoyle Head Shield [standalone]    //
////////////////////////////////////////////////////////////

This is another attachment model - gargoyle head shield.

No custom textures needed!

To import this model into your map, run Worldedit and use Import Manager. Click "Import" button, point to a NSRPG_shield_gargheadshield.mdx file, and click "Open". You can leave path as it is, it doesn't matter.

This model was made from scratch (except the gargoyle head), all credits go to N00byStance. If you use it in your map, give me credits!

Have fun (>^_^)>

~N00byStance