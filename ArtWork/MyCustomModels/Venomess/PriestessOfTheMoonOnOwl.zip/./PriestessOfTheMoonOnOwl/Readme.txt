By: Garfield
Type: Hero Unit

This model is only authorised for download on www.wc3sear.ch and WC3Campaigns.com. If you wish to upload this to your site you must contact me first (via WC3campaigns.com) and ask permission.

Description: A Priestess of the Moon riding an Owl

Legal: This model was created from two models by Blizzard Entertainment, modified by Garfield. Please feel free to use this model in your maps but you MUST give me full credit. If you make any changes to the model you release the new model to either WC3Campaigns.com or wc3sear.ch and give me credit as co-author.
   

Portrait: The portrait is included in the model